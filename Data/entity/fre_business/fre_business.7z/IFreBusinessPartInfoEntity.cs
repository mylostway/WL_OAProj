﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WL_OA.Data
{
    public interface IFreBusinessPartInfoEntity
    {
        string Flist_id { get; set; }
    }
}
