﻿using Chloe.Annotations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace WL_OA.Data.entity
{
    [Table("t_fre_business_other_info")]
    public class FreBusinessOtherInfoEntity : BaseEntity<int>, IFreBusinessPartInfoEntity
    {
        protected string flist_id = "";
        /// <summary>
        /// 关联的交易单号'
        /// </summary>
        [Required]
        [MaxLength(32)]
        public virtual string Flist_id { get { return flist_id; } set { flist_id = value; } }

        public FreBusinessOtherInfoEntity() { }

        public FreBusinessOtherInfoEntity(FreBusinessOtherInfoEntity rhs)
        {
            if (null == rhs) return;
            this.Fid = rhs.Fid;
            this.Fstate = rhs.Fstate;
            this.Flist_id = rhs.Flist_id;
        }

        public static bool operator ==(FreBusinessOtherInfoEntity lhs, FreBusinessOtherInfoEntity rhs)
        {
            if (Object.ReferenceEquals(lhs, null) && !Object.ReferenceEquals(rhs, null)) return false;
            if (!Object.ReferenceEquals(lhs, null) && Object.ReferenceEquals(rhs, null)) return false;
            if (Object.ReferenceEquals(lhs, null) && Object.ReferenceEquals(rhs, null)) return true;
            return (
               lhs.Fid == rhs.Fid &&
               lhs.Fstate == rhs.Fstate &&
               lhs.Flist_id == rhs.Flist_id
           );
        }

        public static bool operator !=(FreBusinessOtherInfoEntity lhs, FreBusinessOtherInfoEntity rhs)
        {
            return !(lhs == rhs);
        }
    }
}
